==================================================================
 SanTyper Pro Suite - macOS Edition (100% Offline)
 Developed & Created by: Sanchitha Charunya
==================================================================

HOW TO RUN:
1. Double-click "SanTyper.app" or "SanTyper_macOS_Launcher.command".
2. If macOS displays "Unidentified Developer" warning:
   Right-click "SanTyper.app" -> click "Open" -> click "Open".
3. SanTyper will launch instantly in your default web browser completely OFFLINE.

INCLUDED:
- Real-time Sinhala & Singlish KeyRep Typing Helper
- Full Unicode <-> DL-Manel / FM-Abhaya Font Converter
- Microsoft Word for Mac Integration Macros in /WordIntegration
- Works on all Apple Silicon (M1/M2/M3/M4) and Intel Macs!
