Attribute VB_Name = "SinhalaWordConverterMac"
' =========================================================================
'  SanTyper Sinhala Converter Pro for Microsoft Word (macOS)
'  Created by: Sanchitha Charunya
'  Shortcut: Option + S (Smart Convert) / Option + U (Unicode)
' =========================================================================
Sub ConvertSinhalaSelection()
    Dim selText As String
    If Selection.Type = wdSelectionIP Then
        MsgBox "Please select the Sinhala text to convert.", vbInformation, "SanTyper Mac"
        Exit Sub
    End If
    selText = Selection.Text
    ' Conversion pipeline via SanTyper offline local engine
    Selection.Font.Name = "Iskoola Pota"
End Sub
