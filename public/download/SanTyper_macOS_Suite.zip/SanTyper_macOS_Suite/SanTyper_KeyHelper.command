#!/bin/bash
# SanTyper KeyHelper (Floating KeyRep-Style Bar) for macOS
# Developed by: Sanchitha Charunya
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
APP_DIR="$DIR/SanTyper.app/Contents/Resources/app"
PORT=18273

if ! lsof -i :$PORT >/dev/null 2>&1; then
    if command -v python3 >/dev/null 2>&1; then
        (cd "$APP_DIR" && python3 -m http.server $PORT --bind 127.0.0.1 >/dev/null 2>&1) &
    fi
    sleep 1
fi

if [ -d "/Applications/Google Chrome.app" ]; then
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --app="http://localhost:$PORT/keyhelper.html" --window-size=680,85 &
elif [ -d "/Applications/Brave Browser.app" ]; then
    "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser" --app="http://localhost:$PORT/keyhelper.html" --window-size=680,85 &
else
    open "http://localhost:$PORT/keyhelper.html"
fi
