#!/bin/bash
# SanTyper Converter Launcher for macOS
# Developed by: Sanchitha Charunya
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
"$DIR/SanTyper.app/Contents/MacOS/SanTyper"
