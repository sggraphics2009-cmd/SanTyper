==================================================================
 SanTyper Pro - Apple iOS Edition (iPhone & iPad)
 Developed & Created by: Sanchitha Charunya
==================================================================

HOW TO INSTALL ON IPHONE / IPAD:

Method 1 (Instant Home Screen App via Safari):
1. Open this website in Safari on your iPhone or iPad.
2. Tap the "Share" button (the box with an upward arrow at the bottom).
3. Scroll down and tap "Add to Home Screen".
4. Tap "Add". The SanTyper app icon will appear on your Home Screen and run in full-screen offline mode!

Method 2 (Apple Configuration Profile):
1. Download "SanTyper_iOS_App.mobileconfig".
2. Go to iPhone Settings -> "Profile Downloaded" -> tap "Install".
3. SanTyper Pro will be permanently pinned to your Home Screen with official branding.
